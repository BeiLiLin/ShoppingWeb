CREATE PROCEDURE del_cartitem(IN oid INT, IN cartid INT, IN comid INT)
  begin
	update t_order  set del_flag =1 where oid=oid;
    update t_commodity  set del_flag =1 where comid=comid;
    update t_cartitem  set del_flag =1 where cartid=cartid;
end;
