CREATE VIEW user_view AS
  SELECT
    `db_shop`.`user`.`uid`      AS `uid`,
    `db_shop`.`user`.`rank`     AS `rank`,
    `db_shop`.`user`.`uname`    AS `uname`,
    `db_shop`.`user`.`password` AS `password`,
    `db_shop`.`user`.`address`  AS `address`,
    `db_shop`.`user`.`tele`     AS `tele`
  FROM `db_shop`.`user`;
