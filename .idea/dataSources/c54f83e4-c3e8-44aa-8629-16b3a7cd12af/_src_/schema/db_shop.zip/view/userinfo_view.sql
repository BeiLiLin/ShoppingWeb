CREATE VIEW userinfo_view AS
  SELECT
    `db_shop`.`user`.`uname` AS `uname`,
    `db_shop`.`user`.`uid`   AS `uid`
  FROM `db_shop`.`user`
  WHERE (`db_shop`.`user`.`uname` = '115');
