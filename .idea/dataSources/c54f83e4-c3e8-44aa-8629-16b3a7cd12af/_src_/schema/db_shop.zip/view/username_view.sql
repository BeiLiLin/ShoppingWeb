CREATE VIEW username_view AS
  SELECT `db_shop`.`user`.`uname` AS `uname`
  FROM `db_shop`.`user`
  WHERE (`db_shop`.`user`.`uname` = 115);
